/* One iOS Now Playing publisher. The audio element owns transport and timing;
 * React supplies track labels. This bridge never starts, pauses or seeks audio. */
(() => {
  'use strict';
  if(window.__munibinSyncNowPlaying||window.__munibinNativePlatform!=='ios')return;
  let element=null,owned=false,metadataKey='',lastNative=null,lastPosition=null;
  const events=['play','playing','pause','ended','loadedmetadata','durationchange','ratechange','seeked','timeupdate','waiting','emptied','error'];
  const finite=value=>{const n=Number(value);return Number.isFinite(n)&&n>=0?n:null;};
  const text=(value,fallback)=>String(value||'').trim()||fallback;
  const post=payload=>{
    try {
      const bridge=window.webkit?.messageHandlers?.['munibin-now-playing'];
      if(!bridge)return false;
      bridge.postMessage(payload);return true;
    } catch {return false;}
  };
  const changed=(previous,next,force)=>{
    if(force||!previous||previous.signature!==next.signature)return true;
    const expected=previous.position+(previous.state==='playing'?(next.at-previous.at)/1000*previous.rate:0);
    return Math.abs(next.position-expected)>1;
  };
  const onMedia=event=>sync(!['timeupdate','waiting'].includes(event.type));
  function bind(next) {
    if(next===element)return;
    if(element)events.forEach(name=>element.removeEventListener(name,onMedia));
    element=next;
    if(element)events.forEach(name=>element.addEventListener(name,onMedia));
  }
  function sync(force=false) {
    let app;
    try {app=window.__munibinAudioPlayerBridge?.getState?.()??window.__munibinQuranPlaylistBridge?.getState?.();} catch {return;}
    // The registered element comes from the active player's attachment routine;
    // preloaded Audio objects never register and cannot take over this session.
    const track=app?.track;
    const quran=String(track?.matnId||'').startsWith('quran-reciter-');
    const raw=window.__munibinNowPlayingAudio;
    bind((quran||track?.audioUrl)&&raw instanceof HTMLMediaElement?raw:null);
    if(!track?.matnId) {
      if(!owned)return;
      try {
        navigator.mediaSession.playbackState='none';
        navigator.mediaSession.metadata=null;
        navigator.mediaSession.setPositionState?.();
      } catch {}
      if(post({state:'stopped'}))owned=false;
      metadataKey='';lastNative=null;lastPosition=null;return;
    }
    const verseKey=app.activeParaId||track.paraId||'';
    const surahNumber=Number(String(verseKey).split(':')[0]);
    const surahs=window.__munibinQuranPlaylistBridge?.getSurahs?.()||[];
    const matn=window.__munibinMatnNowPlayingMeta?.[track.matnId]||{};
    const title=quran?text(surahs.find(s=>Number(s.surah)===surahNumber)?.nameArabic,'القرآن الكريم'):text(track.matnTitle||matn.title,'متن');
    const artist=quran?text(track.matnTitle,'القارئ'):text(matn.author,'المتون');
    const album=quran?'القرآن الكريم':'المتون';
    const displayTitle=`${title} — ${artist}`;
    if(document.title!==displayTitle)document.title=displayTitle;
    const source=element?.currentSrc||element?.src||track.audioUrl||'';
    const trackId=`${track.matnId}|${source}`;
    // Raw media properties are current even if the WebView's React updates lag
    // while locked. Loading alone must never falsely report audible playback.
    const state=element?(element.paused||element.ended?'paused':'playing'):(app.playing?'playing':app.paused||app.loading?'paused':'stopped');
    const rate=Math.max(.01,finite(element?.playbackRate)??finite(app.playbackRate)??1);
    const duration=finite(element?.duration)??finite(app.duration)??0;
    const current=finite(element?.currentTime)??finite(app.currentTime)??0;
    const position=duration>0?Math.min(duration,current):current;
    const next={signature:JSON.stringify([trackId,title,artist,album,state,rate,duration]),state,rate,position,at:Date.now()};
    const session=navigator.mediaSession;
    if(session) {
      const key=JSON.stringify([title,artist,album]);
      if(metadataKey!==key&&typeof MediaMetadata!=='undefined') {
        try {
          session.metadata=new MediaMetadata({title,artist,album,artwork:[
            {src:'/icon-192.png',sizes:'192x192',type:'image/png'},
            {src:'/icon-512.png',sizes:'512x512',type:'image/png'}
          ]});metadataKey=key;
        } catch {}
      }
      try {
        const playbackState=state==='stopped'?'none':state;
        if(session.playbackState!==playbackState)session.playbackState=playbackState;
      } catch {}
      if(changed(lastPosition,next,force)) {
        try {
          if(duration>0)session.setPositionState?.({duration,position,playbackRate:rate});
          else session.setPositionState?.();
          lastPosition=next;
        } catch {}
      }
    }
    if(changed(lastNative,next,force)&&post({title,artist,album,state,verseKey,trackId,elapsedTime:position,duration,playbackRate:rate}))lastNative=next;
    owned=true;
  }
  window.__munibinSyncNowPlaying=sync;
  const wake=()=>sync(true);
  window.addEventListener('munibin-quran-audio-state',()=>sync());
  window.addEventListener('munibin-native-resume',wake);
  window.addEventListener('pageshow',wake);
  document.addEventListener('visibilitychange',wake);
  // Fallback for a restored session or a newly attached element; no repeated
  // native repaint occurs when elapsed time follows the expected playback rate.
  window.setInterval(()=>sync(),2000);
  sync();
})();
